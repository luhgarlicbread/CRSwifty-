#include <iostream>
#include <memory.h>
#include <inttypes.h>
typedef char BYTE;
#define MIN(X, Y) (((X) < (Y)) ? (X) : (Y))
int main(int argc, char const *argv[])
{
    unsigned int ff = (-30);
	unsigned int ff3 = (-5);
	int ff2 = (-2);
    // BYTE* data = (BYTE*)30;
    // printf("%p\n",(BYTE*)30 +ff);
	 sizeof(2);
	printf("%d", MIN(ff,sizeof(2)));
    return 0;
}
// void _plat__NvVirtualMemoryRead(unsigned int startOffset, unsigned int size,
// 				void *data)
// {
// 	uint32_t nvIndex;
// 	// struct virtual_nv_index_cfg nvIndexConfig;
// 	unsigned int offset;

// 	nvIndex = NvOffsetToNvIndex(startOffset);
// 	GetNvIndexConfig(nvIndex, &nvIndexConfig);

// 	/* Calculate offset within this section. */
// 	startOffset = startOffset - NvIndexToNvOffset(nvIndex);

// 	offset = startOffset;
// 	while (size > 0) {
// 		int section_offset;
// 		int copied;

// 		if (offset < NV_INDEX_READ_OFFSET) {
// 			/*
// 			 * The first 4 bytes are supposed to represent a pointer
// 			 * to the next element in the NV index list; we don't
// 			 * have a next item, so return 0.
// 			 */
// 			copied = MIN(sizeof(TPM_HANDLE) - offset, size);

// 			memset((BYTE *) data, 0, copied);
// 		} else if (offset < NV_DATA_READ_OFFSET) {
// 			/*
// 			 * The NV_INDEX section is the second section, which
// 			 * immediately folows the 'next' pointer above.
// 			 */
// 			section_offset = offset - NV_INDEX_READ_OFFSET;
// 			copied = MIN(VIRTUAL_NV_INDEX_HEADER_SIZE -
// 				     section_offset, size);

// 			CopyNvIndex((BYTE *)data + offset - startOffset,
// 				    section_offset,
// 				    copied,
// 				    nvIndex, nvIndexConfig.size);
// 		} else if (offset < NV_DATA_READ_OFFSET + nvIndexConfig.size) {
// 			/*
// 			 * The actual NV data is the final section, which
// 			 * immediately follos the NV_INDEX.
// 			 */
// 			section_offset = offset - NV_DATA_READ_OFFSET;
// 			copied = MIN(nvIndexConfig.size - section_offset, size);

// 			nvIndexConfig.get_data_fn((BYTE *)data + offset -
// 						  startOffset,
// 						  section_offset,
// 						  copied);
// 		} else {
// 			/* More data was requested than is available. */
// #ifdef CR50_DEV
// 			cprints(CC_TPM,
// 				"Invalid vNVRAM read, offset: %x, size: %x",
// 				offset, size);
// #endif
// 			memset((BYTE *)data + offset - startOffset, 0,
// 			       size);
// 			break;
// 		}

// 		offset += copied;
// 		size -= copied;
// 	}
// }