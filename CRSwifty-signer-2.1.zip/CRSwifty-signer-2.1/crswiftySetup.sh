# Get current firmware image

flashrom -p host -r original.bin