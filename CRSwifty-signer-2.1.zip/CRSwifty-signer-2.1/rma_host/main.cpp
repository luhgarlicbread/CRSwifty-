#include "constants.h"
#include <stdio.h>
#include <string>
#include <dbus-c++/dbus.h>
#include 
int main(int argc, char const *argv[])
{
    printf("Toolkit made by %s!\n", BRAND_NAME);
    printf("Usage instructions: \n");
    std::string usageMsg;

    
    printf("\tYou must run this on ChromeOS under the chronos account. After running this, you will be prompted with the shimless rma code later used to run a cr50 rma unlock.\n");
    
    int major_version, minor_version, micro_version;
    DBus::ObjectProxy
    printf("DBus version: %d.%d.%d\n", major_version,minor_version,micro_version);
    
    return 0;
}
